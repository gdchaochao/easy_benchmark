insert into web_sales (select * from wsv);
rollback;

